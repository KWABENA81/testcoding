Included in the zip file are the java dev challenge coding, and related files.  
The actually solution that calcutes toll charges on thre ETR, is EtrJavaDev-1.0-SNAPSHOT.jar. 

To run the program, ensure the files EtrJavaDev-1.0-SNAPSHOT.jar and interchanges.json are 
in the same folder.  As well, the PC should have Java 11 installed on it, at least. 
Then run the following on the command promt:
java -jar EtrJavaDev-1.0-SNAPSHOT.jar  interchanges.json

#1. The program presents a display of all available ramp names, as per the files.
#2	Select 'S' or 's' to start, then follow the prompts.
#3	To exit, proceed until the main prompt, then press 'e' or 'E'.
